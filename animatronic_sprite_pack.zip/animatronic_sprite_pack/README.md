# Haunted Pizzeria Animatronic Sprite Pack

Five original pixel-art animatronics, each with a **healthy** and a **destroyed** version.

| Character | Description |
|---|---|
| Static | Rusty arcade-mascot robot with a CRT-TV head |
| Marigold | Yellow fox animatronic |
| Plum | Purple owl animatronic |
| Barnaby | Brown beaver animatronic |
| Gully | Green gator animatronic |

## Folder layout
```
<Character>/<healthy|destroyed>/
  spritesheet.png      4x scale, 128x208 per frame, one animation per row
  spritesheet_1x.png   native 32x52 per frame (scale with nearest-neighbor)
  spritesheet.json     frame rects, fps, loop flags
  frames/<anim>/       individual PNG frames
  previews/            GIF previews + labelled contact sheet
```

## Animations (all characters, both states, facing right — flip for left)
| Row | Name | Frames | FPS | Loop |
|---|---|---|---|---|
| 0 | idle | 4 | 6 | yes |
| 1 | walk_forward | 6 | 10 | yes |
| 2 | walk_backward | 6 | 8 | yes |
| 3 | jump | 6 | 10 | no |
| 4 | crouch | 3 | 12 | no |
| 5 | crouch_idle | 2 | 4 | yes |

## Notes
- Every sheet uses the same layout, so swapping a character or switching healthy→destroyed is just a texture swap.
- Pivot / feet line: (64, 200) in each 4x frame.
- `jump` plays once (anticipation, launch, rise, apex, fall, land); move the sprite vertically in code.
- `crouch` plays once into `crouch_idle`; play `crouch` reversed to stand.
- Destroyed versions have torn fur with exposed endoskeleton, a dead eye, broken jaws/ears, and sparks that flicker on some frames.
